import type { Metadata } from "next";import "./globals.css";
export const metadata:Metadata={title:"Campus Wallet",description:"A clearer way to manage student money."};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>}
