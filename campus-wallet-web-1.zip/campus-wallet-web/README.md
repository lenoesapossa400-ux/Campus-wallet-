# Campus Wallet Web

Responsive Next.js + Supabase student budgeting web app, in midnight blue and cyan. Features include email/password authentication, manually entered starting balance, income and expenses, category allocations, partial-spending confirmation, savings goals, reports and optional AI money advice.

## Setup
1. Install Node.js 20.9+ and npm.
2. Extract the ZIP and open a terminal in this folder. Run `npm install`.
3. In Supabase SQL Editor, run all of `supabase/schema.sql`.
4. Copy `.env.example` to `.env.local`; fill in your Supabase project URL and publishable/anon key. Never use a service-role key in the browser.
5. Set Supabase Auth Site URL / redirect URL to `http://localhost:3000` for local development.
6. Run `npm run dev`, then open `http://localhost:3000`.
7. Run financial logic tests with `npm test`.

Optional AI: set server-side `OPENAI_API_KEY` and optionally `OPENAI_MODEL` in `.env.local`, then restart the server.

## Money rules
All amounts are stored as integer lisente (100 lisente = M1.00). Balance = starting balance + income - expenses. Allocation reserves funds without spending them. Category remaining = allocation - category expenses.

## Production note
This is a starter application and has not been deployed or connected to your Supabase project. Before a public launch, use atomic database functions/RPC for budget and balance checks, and for savings contributions (currently multiple requests); add rate limiting to the AI endpoint and test against your own Supabase project. No bank payments or real-money transfers are implemented.
